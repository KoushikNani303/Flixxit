# Disney hotstar Clone Web Application with Tmdb Api using Typescript, Redux, Axios, React Router Dom, Material Ui

Preview - https://disney-hotstart-hrhp.netlify.app/
